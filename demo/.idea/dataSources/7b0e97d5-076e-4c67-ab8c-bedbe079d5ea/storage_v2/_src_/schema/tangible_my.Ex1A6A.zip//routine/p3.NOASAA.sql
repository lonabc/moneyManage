create
    definer = root@localhost procedure p3()
begin
    declare score int default 20;
    declare result varchar(10);
    if score>=20 then
          set result:='中年人';
    elseif score>=10 then
        set result :='少年';
    else
        set result :='未知';
    end if;
    select result;
end;

