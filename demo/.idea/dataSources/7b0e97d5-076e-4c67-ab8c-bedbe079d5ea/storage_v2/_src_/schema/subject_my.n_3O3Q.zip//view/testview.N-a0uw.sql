create definer = root@localhost view testview as
select `subject_my`.`course`.`Cname` AS `Cname`
from `subject_my`.`course`;

