create definer = root@localhost view sjp as
select `subject_my`.`spj`.`Sno` AS `Sno`, `subject_my`.`spj`.`Pno` AS `Pno`, `subject_my`.`spj`.`Qty` AS `Qty`
from `subject_my`.`spj`
where (`subject_my`.`spj`.`Jno` =
       (select `subject_my`.`j`.`Jno` from `subject_my`.`j` where (`subject_my`.`j`.`Jname` = '三建')));

