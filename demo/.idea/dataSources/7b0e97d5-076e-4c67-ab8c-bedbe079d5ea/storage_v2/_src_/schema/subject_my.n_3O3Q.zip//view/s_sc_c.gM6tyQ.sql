create definer = root@localhost view s_sc_c as
select `subject_my`.`student`.`Sno`   AS `Sno`,
       `subject_my`.`student`.`Sname` AS `Sname`,
       `subject_my`.`sc`.`Grade`      AS `Grade`,
       `subject_my`.`course`.`Cname`  AS `Cname`
from `subject_my`.`student`
         join `subject_my`.`sc`
         join `subject_my`.`course`
where ((`subject_my`.`student`.`Sno` = `subject_my`.`sc`.`Sno`) and
       (`subject_my`.`sc`.`Cno` = `subject_my`.`course`.`Cno`))
order by `subject_my`.`student`.`Sno`;

