create definer = root@localhost view is_student as
select `subject_my`.`student`.`Sno`   AS `Sno`,
       `subject_my`.`student`.`Sname` AS `Sname`,
       `subject_my`.`student`.`Sage`  AS `Sage`
from `subject_my`.`student`
where (`subject_my`.`student`.`Sdept` = '信息系');

