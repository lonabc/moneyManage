create definer = root@localhost view testsubject as
select `subject_my`.`course`.`Cno` AS `Cno`
from `subject_my`.`course`
where (`subject_my`.`course`.`Cname` = '信息系统');

