create definer = root@localhost view is_s1 as
select `subject_my`.`student`.`Sno`   AS `Sno`,
       `subject_my`.`student`.`Sname` AS `Sname`,
       `subject_my`.`sc`.`Grade`      AS `Grade`
from `subject_my`.`student`
         join `subject_my`.`sc`
where ((`subject_my`.`sc`.`Cno` = 1) and (`subject_my`.`student`.`Sdept` = '信息系') and
       (`subject_my`.`sc`.`Sno` = `subject_my`.`student`.`Sno`));

